---
name: chemchain-demand-analysis
description: Analyze, refine, or draft ChemChain product requirements using a five-question framework covering business value, end-to-end scenarios, data definitions, role-specific needs, and exception handling. Use when reviewing ChemChain feedback, writing PRDs, preparing requirement reviews, or evaluating changes to quotation, pricing, inventory, order, SKU, or workflow features.
---

# ChemChain 需求分析

Use this skill to turn a feature request into a complete, explainable business solution. Do not begin with the page or field to add; begin with the business problem.

## Workflow

1. Restate the request in one sentence and identify the intended business outcome.
2. Work through the five questions below. State unknowns explicitly and list the people or artifacts needed to resolve them.
3. Produce a requirement brief or PRD section using the output template in [references/demand-analysis-template.md](references/demand-analysis-template.md).
4. Before review, verify that the normal flow, downstream use, data source, roles, and exception rules are all covered.

## The five questions

### 1. Why is this worth doing?

Return to the real business scenario and pain point. Distinguish a single user's preference from a recurring or cross-role problem. If multiple people are affected, validate the request with the requester and the affected users before setting priority.

### 2. Where does it appear in the end-to-end flow?

Place the requested capability in the full workflow. Check whether its information must be shown, transferred, validated, or reused at later nodes. Do not deliver an isolated field that does not work in the rest of the flow.

### 3. What data is needed, and what does each field mean?

Align the source, definition, dimension, unit, calculation, update timing, and permission for each material field. Watch for mismatches such as total price versus unit price, total quantity versus per-item quantity, or a requested business value versus an available system value. Confirm the final data contract with business and engineering.

### 4. What does each role need to see and do?

Different roles may need different data, operations, and permissions. Identify the role-specific task at each node; avoid giving every user the same view or action set by default.

### 5. How should success, exceptions, and branches be handled?

Define the normal successful path, validation failures, missing data, conflicts, and reversals. For every material exception, decide whether to prompt, request review, block, allow release, or support rollback. Name the responsible role where applicable.

## Deliverable standard

Treat the analysis as complete only when it makes all five aspects clear:

- Value: the business problem and priority are explicit.
- Flow: the capability fits the full journey and downstream nodes.
- Data: sources and dimensions are aligned and implementable.
- Roles: each user has an appropriate view and action.
- Boundaries: normal and exceptional behavior are testable.

## ChemChain-specific reminders

- Trace quotation features across inquiry, inventory or quasi-stock evaluation, sourcing, pricing, quotation, order confirmation, procurement, and fulfillment when relevant.
- For pricing or inventory displays, confirm whether the business needs unit price, total price, a quoted specification, an available specification, inventory quantity, or total available mass before proposing UI.
- For state labels such as archived, identify the underlying business result and task state; do not assume one UI status maps to one business meaning.
- For new order fields, clarify whether the value is a customer requirement, product attribute, system-calculated value, or downstream procurement input.
